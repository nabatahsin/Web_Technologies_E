<!DOCTYPE html>
<html>
<head>
	<title>index</title>
</head>
<body>
  <a href="MVC/Controllers/loginController.php">Login</a>

</body>
</html>
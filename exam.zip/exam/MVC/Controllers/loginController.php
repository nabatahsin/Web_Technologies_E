<?php
header('location:../Views/log.php');
?>
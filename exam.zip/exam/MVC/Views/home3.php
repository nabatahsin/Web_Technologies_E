<?php
require_once('../Models/alldb.php');
session_start();

    $res=auth1();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Admin</title>
</head>
<body>
  <h1>Admins</h1>

    
    <table border="1">
      <tr>
        <th>Admin Id</th>
         <th>Pass</th>
      </tr>
      <?php while ($r2=$res->fetch_assoc()) { ?>
      <tr>
        <td><?php echo $r2['id']; ?></td>
        <td><?php echo $r2['pass']; ?></td>
        
        <form method="post" action=" ">
        <td><button name="logout" >Logout</button></td>

      </form>
      </tr>
 <?php } ?>
    </table>
   </form> 
   
</body>
</html>